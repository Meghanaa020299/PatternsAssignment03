package question01;

import question01.question01;

public class Question1Driver {

	public static void main(String[] args) {
		question01<Integer> a = new question01<>(5);
		a.setData(10);
		System.out.println(a.getData());

	}

}
