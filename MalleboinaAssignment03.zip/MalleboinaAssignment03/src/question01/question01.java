package question01;

public class question01<T> {
	private T data;

	   public question01(T data) {
	      this.data = data;
	   }

	   public T getData() {
	      return this.data;
	   }

	   public void setData(T data) {
	      this.data = data;
	   }

}
