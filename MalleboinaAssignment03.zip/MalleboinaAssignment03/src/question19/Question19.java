package question19;

import question19.Question19;

public class Question19 extends Thread {
    public void run() {
        System.out.println("Thread is running.");
    }
    
    public class MyRunnable implements Runnable {
        public void run() {
            System.out.println("Thread is running.");
        }
    }
public static void main(String args[]) {
// Creating and starting a thread object
	Question19 myThread = new Question19();
myThread.start();
Question19 myRunnable = new Question19();
Thread myThread1 = new Thread(myRunnable);
myThread1.start();

}
}