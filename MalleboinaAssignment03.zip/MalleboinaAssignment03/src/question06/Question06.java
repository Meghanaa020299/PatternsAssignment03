package question06;

public class Question06 {
	public static void main(String[] args) 
    { 
        String s1 = "Malleboina";
        String s2 =  "Meghanaa"+s1;
        System.out.println(s2);
        System.out.println(System.nanoTime());
        
        StringBuffer b1=new StringBuffer("Meghanaa");  
        b1.append("Malleboina");  
        System.out.println(b1);  
        System.out.println(System.nanoTime());
        
    }

}
