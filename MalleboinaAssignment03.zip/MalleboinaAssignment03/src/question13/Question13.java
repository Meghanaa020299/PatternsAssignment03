package question13;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

public class Question13 {
	public static void main (String[] args) {
        ArrayList<String> str = new ArrayList<String>();
        str.add("a1");
        str.add("a2");
        str.add("a3");
        str.add("a4");
        System.out.println("ArrayList elements are:");
        Iterator it = str.iterator();
        while (it.hasNext())
            System.out.println(it.next());
  
        Vector<String> str1 = new Vector<String>();
        str1.addElement("b1");
        str1.addElement("b2");
        str1.addElement("b3");
        str1.addElement("b4");
        System.out.println("\nVector elements are:");
        Enumeration<String> str2 = str1.elements();
        while (str2.hasMoreElements())
           System.out.println(str2.nextElement());
    }

}
