package question09;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Question09 {
	 public static void main(String[] args) {
	      try (BufferedReader reader = new BufferedReader(new FileReader("Details.txt"))) {
	         String s1 = reader.readLine();
	         while (s1 != null) {
	            System.out.println(s1);
	            s1 = reader.readLine();
	         }
	      } catch (IOException s2) {
	         s2.printStackTrace();
	      }
	   }

}
