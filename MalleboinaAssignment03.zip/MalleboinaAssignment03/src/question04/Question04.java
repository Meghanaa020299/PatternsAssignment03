package question04;

import question04.Question041;
import question04.Question042;

public class Question04 {

	  public static void main(String[] args) {
		 // Question041.publicMethod(); // Output: This is a public method in superclass.
		  //Question042.publicMethod(); // Output: This is a public method in subclass.

	       // Question041.privateMethod(); // Error: The method privateMethod() from the type Superclass is not visible
	        //Question042.privateMethod(); // Error: The method privateMethod() from the type Subclass is not visible
	    }
	
}
