package question04;

import question04.Question041;

public class Question042  extends Question041{
    // This is a new method and not an override of the privateMethod in superclass
    private static void privateMethod() {
        System.out.println("This is a private method in subclass.");
    }
    
    // This is a new method and not an override of the publicMethod in superclass
    public static void publicMethod() {
        System.out.println("This is a public method in subclass.");
    }

}
