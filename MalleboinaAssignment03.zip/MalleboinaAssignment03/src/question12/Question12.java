package question12;

import question12.Question12;

public class Question12 {
	protected void finalize() throws Throwable { 
		try {
			System.out.println("try Block");
			}
			finally {
			System.out.println("finally block");
			}
		}

	public static void main(String[] args) throws Throwable {
	final int a1=10;
	System.out.println(a1);
	Question12 d1= new Question12();
		
		}

}
