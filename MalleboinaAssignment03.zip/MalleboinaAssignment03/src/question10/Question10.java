package question10;

import java.io.FileNotFoundException;
import java.io.IOException;

import question10.SubClass;
import question10.SuperClass;

class SuperClass {
    public void doSomething() throws IOException {
        System.out.println("super class");
    }
}

class SubClass extends SuperClass {
    // This is not allowed, it will result in a compile-time error
    public void doSomething() throws FileNotFoundException {
        System.out.println("sub class");
    }
}
public class Question10 {
	 public static void main(String[] args) throws IOException  {
	        SuperClass s1 = new SuperClass();
	        SubClass s2 = new SubClass();
	        
	        try {
	            s1.doSomething();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        
	        try {
	            s2.doSomething();
	        } finally {
	        	System.out.println("finally block");
	        }
	    }
	

}
