package question03;

import question03.Circle;
import question03.Question03;
import question03.Rectangle;

public class Question3Driver {

	public static void main(String[] args) {
		Question03 shape = new Question03();
	        Circle circle = new Circle();
	        Rectangle rectangle = new Rectangle();

	        Question03 newShape = shape.draw(); // returns a Shape
	        Question03 newCircle = circle.draw(); // returns a Circle
	        Question03 newRectangle = rectangle.draw(); // returns a Rectangle

	        System.out.println(newShape.getClass()); // prints "class Shape"
	        System.out.println(newCircle.getClass()); // prints "class Circle"
	        System.out.println(newRectangle.getClass()); // prints "class Rectangle"
	}

}
