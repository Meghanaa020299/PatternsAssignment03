package question03;

import question03.Circle;
import question03.Question03;
import question03.Rectangle;

public class Question03 {
	public Question03 draw() {
        System.out.println("Drawing shape...");
        return new Question03();
    }
}

class Circle extends Question03 {
    @Override
    public Circle draw() {
        System.out.println("Drawing circle...");
        return new Circle();
    }
}

class Rectangle extends Question03 {
    @Override
    public Rectangle draw() {
        System.out.println("Drawing rectangle...");
        return new Rectangle();
    }

}
