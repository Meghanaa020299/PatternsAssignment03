package question05;

public class Question05 {
	public static void main(String[] args){  
        StringBuffer a1=new StringBuffer("hi");  
        a1.append("meghanaa");  
        System.out.println(a1);  
        System.out.println(System.nanoTime());
        
        StringBuilder a2=new StringBuilder("hi");  
        a2.append("meghanaa");  
        System.out.println(a2);  
        System.out.println(System.nanoTime());
    }   

}
