package question18;

import question18.Question18;

public class Question18 extends Thread{
    public void run() {
        System.out.println("Thread is running...");
    }

    public static void main(String[] args) {
    	Question18 t1 = new Question18();

        t1.start(); // First time thread is started

        try {
            t1.join(); // Wait for thread to finish
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Trying to start the same thread object again will result in an IllegalThreadStateException
        t1.start(); // Second time thread is started - will throw an exception
    }
}