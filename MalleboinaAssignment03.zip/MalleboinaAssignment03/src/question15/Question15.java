package question15;

import java.util.HashMap;
import java.util.Hashtable;

public class Question15 {
	public static void main(String[] args) {
        Hashtable<String, Integer> str1 = new Hashtable<>();
        str1.put("a1", 1);
        str1.put("a2", 2);
        str1.put("a3", 3);

        for (String s1 : str1.keySet()) {
            int s2 = str1.get(s1);
            System.out.println(s1 + "Output is is: " + s2);
        }
        System.out.println("Using HashMap");
    HashMap<String, Integer> str3 = new HashMap<>();
    str3.put("a1", 1);
    str3.put("a2", 2);
    str3.put("a3", 3);

    for (String str4 : str3.keySet()) {
        int str5 = str3.get(str4);
        System.out.println(str4 + "Output is: " + str5);
    }
 }  

}
