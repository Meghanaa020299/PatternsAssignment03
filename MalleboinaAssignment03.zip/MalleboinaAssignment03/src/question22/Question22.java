package question22;

public class Question22 {

	public static void main(String args[]) {
		String s1="Meghanaa";
		String s2="Malleboina "+s1;
		System.out.println(s2);
		System.out.println(s1);
		
		
	}

}
