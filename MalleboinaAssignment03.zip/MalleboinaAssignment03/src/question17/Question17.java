package question17;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class Question17 {
	public static void main(String[] args) {
		
		List<Integer> l1 = new CopyOnWriteArrayList<>();
		l1.add(1);
		l1.add(2);
		l1.add(3);

		Iterator<Integer> itr1 = l1.iterator();

		while (itr1.hasNext()) {
		    Integer a1 = itr1.next();
		    System.out.println(a1);
		    l1.remove(a1); // modification during iteration
		}
		List<Integer> l2 = new ArrayList<>();
		l2.add(1);
		l2.add(2);
		l2.add(3);

		Iterator<Integer> itr = l2.iterator();

		while (itr.hasNext()) {
		    Integer a2 = itr.next();
		    System.out.println(a2);
		    l2.remove(a2); // modification during iteration
		}
		
	  }

}
