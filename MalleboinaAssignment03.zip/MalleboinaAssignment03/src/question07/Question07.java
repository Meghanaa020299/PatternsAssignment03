package question07;

public class Question07 {
	public Question07() {
		System.out.println("Illegal modifier for the "
				+ "constructor in type Question07; only public, protected & private are permitted...So, "
				+ "To simply prevent a class mistake, I changed the final to public and included the code with a final constructor to the documentation.\r\n");
	}

}
