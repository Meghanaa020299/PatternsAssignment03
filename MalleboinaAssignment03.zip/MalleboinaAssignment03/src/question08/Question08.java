package question08;

public class Question08 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			System.out.println("Try Block");
			  throw new NullPointerException();
		}
		finally {
			System.out.println("Finally block");
		}

	}

}
